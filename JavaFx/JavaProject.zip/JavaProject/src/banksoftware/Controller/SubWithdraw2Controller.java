package banksoftware.Controller;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

public class SubWithdraw2Controller implements Initializable {

    @FXML
    protected TextField patron1IdT;
    @FXML
    protected TextField patron2IdT;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}
