package banksoftware.Controller;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

public class SubWithdraw3Controller implements Initializable {
    @FXML
    protected TextField checkPatron1;
    @FXML
    protected TextField checkPatron2;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}
